# -*- coding: utf-8 -*-
"""
Created on Wed Oct 28 14:17:28 2020

@author: Matt
"""

#Needed dependencies:
#   pip install selenium

#   If using chrome get https://sites.google.com/a/chromium.org/chromedriver/downloads ;
#       Then add to PATHS and ideally place binary in same place as python script

#Note: currently signup genius is configured to offer swim time session 48 hours in advance relative to 
#       the swim time you want. So if you want 5:30 pm on Monday you can sign up at 5:30 pm on Saturday

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains;
import os
import time
from datetime import datetime
from datetime import date
import re

def main():
    #main variables
    #url = "https://www.signupgenius.com/go/904054caea72fa7f58-september"
    #url = "https://www.signupgenius.com/go/904054caea72fa7f58-october"
    url = "https://www.signupgenius.com/go/904054caea72fa7f58-november"
    swim_date = "11/16/2020" #"10/01/2020" #"9/29/2020"
    swim_time = "5:30pm" #"11:00am" #"6:00am" #5:30pm" #11:00am"
    swim_type = "Shallow" #"Shallow" #Deep
    keyword = "checkTheBox"
    
    #swimmer names
    names_first = ["matt", "steven", "joel", "david"]
    names_last = ["h", "l", "j", "m"]
    emails = ["matthew.r.hannon@gmail.com", "Steven.Lane11@gmail.com", "jrbjustus@gmail.com", "physicsdmurrell@gmail.com"]
        
    #names_first = ["matt", "steven", "joel"]
    #names_last = ["h", "l", "j"]
    #emails = ["matthew.r.hannon@gmail.com", "Steven.Lane11@gmail.com", "jrbjustus@gmail.com"]
    #names_first = ["steven", "joel"]
    #names_last = ["l", "j"]
    #emails = ["Steven.Lane11@gmail.com", "jrbjustus@gmail.com"]
    
    #Timing loop

    now = datetime.now()
    #FIXME: verify date too, although it should have been done below when parsing html
    
    #Convert from 12 to 24 hour clock
    #test_time = "8:44am"
    #twelve_hour_time = datetime.strptime(test_time, "%I:%M%p")
    
    twelve_hour_time = datetime.strptime(swim_time, "%I:%M%p")
    military_hour_time = datetime.strftime(twelve_hour_time, "%H:%M")
    print(military_hour_time)
    
    now_time = time.strftime("%H:%M")
    print(now_time)
    
    test = False
    while test == False:
        now_time = time.strftime("%H:%M")
        
        #Compare times
        if now_time >= military_hour_time:
            print("AFTER!")
            test = True
        else:
            print("BEFORE")
            time.sleep(5)
        
    time.sleep(10) #need to do this smarter!
    
    #return 
    
    for index, name in enumerate(names_first):
        print("index=" + str(index) + " name=" + names_first[index] + " " + names_last[index] + " email=" + emails[index])

        chrome_options = Options()
        #chrome_options.add_argument("--headless")
        chrome_options.add_argument("--window-size=1024x1400")
    
        chrome_driver = os.path.join(os.getcwd(), "chromedriver")
    
        driver = webdriver.Chrome(chrome_options=chrome_options, executable_path=chrome_driver)
        driver.get(url)
        
        #Remove cookies/privacy banner
        #driver.find_element_by_class_name("sug-notice--privacy-button-wrapper").click()
        
        #need to parse html and find correct checkbox id
        html_source = driver.page_source
        #print(html_source)
        
        #index = str.find(sub,start,end) (-1 if not found)
        index0 = html_source.find(swim_date)
        if index0 == -1:
            print("ERROR: swim_date (" + swim_date + ") is not found on site...")
            return
        
        index1 = html_source.find(swim_time, index0)
        if index1 == -1:
            print("ERROR: swim_time (" + swim_time + ") is not found proceeding swim_date...")
            return        
        
        index2 = html_source.find(swim_type, index1)
        if index2 == -1:
            print("ERROR: swim_type (" + swim_type + ") is not found proceeding swim_time...")
            return        
            
        index3 = html_source.find(keyword, index2)
        if index3 == -1:
            print("ERROR: keyword (" + keyword + ") is not found proceeding swim_type... Probably because the listing is now full.")
            return           
        
        #extract string between ( )
        if html_source[index3+len(keyword)] != '(':
            print("ERROR! no ( !")
            return
        
        counter = 0
        while html_source[index3+len(keyword)+counter] != ')':
            counter = counter + 1
            
            if counter > 20:
                print("ERROR: counter > 20! Got lost looking for end of expression.")
                return
            
        interesting_checkbox = html_source[html_source.find("(", index3)+1:html_source.find(")",index3)]
        print(interesting_checkbox)
        
        checkbox_id = "checkbox" + interesting_checkbox
        print(checkbox_id)
        
        driver.execute_script("document.getElementById(\"" + checkbox_id + "\").checked = true;")
        
        time.sleep(3) #need to do this smarter!
        
        driver.execute_script("document.forms[0].submit();")
        
        time.sleep(4) #need to do this smarter!
    
        driver.find_element_by_id('firstname').send_keys(str(names_first[index])) #("doug");
        driver.find_element_by_id('lastname').send_keys(str(names_last[index])) #("lanceman");
        driver.find_element_by_id('email').send_keys(str(emails[index])) #("douglanceman@gmail.com");
        
        #Select Member radio box
        #ugly... should do this by value not by id
        #driver.execute_script("document.getElementById(\"1_2807823_id\").click();")
        driver.execute_script("document.getElementById(\"1_2964520_id\").click();")
        
        #might need to have set focus on the text boxes for form to pass correctly
        driver.execute_script("var signupBtn = document.getElementsByName(\"btnSignUp\"); signupBtn[0].click();")
        
        #----------------------------------------------------------#
    
    time.sleep(2)
    
    # screenshot capture
    driver.get_screenshot_as_file("python-github.png")
    driver.close()

if __name__ == '__main__' : main()